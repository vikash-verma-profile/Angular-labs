<?php
    header("Content-Type: text/plain");
?>
[
    {
        "name": "Person1",
        "email": "nicholas@some-domain-name.com"
    },
    {
        "name": "Person2",
        "email": "jimsmith@some-domain-name.com"
    },    {
        "name": "Person3",
        "email": "mj@some-domain-name.com"
    }
]